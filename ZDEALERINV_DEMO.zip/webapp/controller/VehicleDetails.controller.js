sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History"
], function(Controller, MessageBox, Utilities, History) {
	"use strict";

	return Controller.extend("zdi.controller.VehicleDetails", {
		// for nav back
		onNavBack: function(oEvent) {
			var oHistory, sPreviousHash;

			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("VehicleList", {}, true);
			}
		},
		// initialize control
		onInit: function() {
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Z_VEHICLE_MASTER_SRV");
			this.getView().setModel(oModel);

			this.getOwnerComponent().getRouter().attachRoutePatternMatched(this._onRoutMatched, this);
		},
		// Route Match
		_onRoutMatched: function(oEvent) {
			var paramId = oEvent.getParameters().arguments.oid;
			// 			var ocustId = oEvent.getParameters().arguments.ocust;
			var oGuid = oEvent.getParameters().arguments.ogid;
			console.log(oGuid);
			this.getView().byId("idvehicleDetails").bindElement("/zc_model('" + paramId + "')");
			// 			this.getView().byId("idAccessoryData").bindElement("/zc_c_vehicle(guid'" + oGuid + "')");

			//console.log(this.getOwnerComponent().getModel("LocalDataModel"));
		}
	});

});