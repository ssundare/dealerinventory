sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment"
], function(Controller, MessageBox, Utilities, History, JSONModel, Filter, MessageToast, Fragment) {
	"use strict";

	return Controller.extend("zdi.controller.VehicleList", {

		onBeforeVariantSave: function(oEvent) {
			if (oEvent.getParameter("context") === "STANDARD") {
				this._updateCustomFilter();
			}
		},

		// 		onBeforeVariantFetch: function(oEvent) {

		// 			this._updateCustomFilter();
		// 		},

		_updateCustomFilter: function() {
			var oSmartFilterbar = this.getView().byId("smartFilterBar");

			if (oSmartFilterbar) {

				var oCtrl = oSmartFilterbar.determineControlByName("MyOwnFilterField");

				if (oCtrl) {
					oSmartFilterbar.setFilterData({
						_CUSTOM: {
							MyOwnFilterField: oCtrl.getSelectedKey()
						}
					});
				}
			}
		},
		OnBeforeRebindTable: function(oEvent) {
			var oBindingParams = oEvent.getParameter("bindingParams");
			oBindingParams.parameters = oBindingParams.parameters || {};
			console.log(oBindingParams);
			var oSmartTable = oEvent.getSource();
			var oSmartFilterBar = this.byId(oSmartTable.getSmartFilterId());
			console.log(oSmartFilterBar);
			var vCategory;
			if (oSmartFilterBar instanceof sap.ui.comp.smartfilterbar.SmartFilterBar) {

				var oCustomControl = oSmartFilterBar.getControlByKey("keyStatusFilter");
				if (oCustomControl instanceof sap.m.ComboBox) {
					vCategory = oCustomControl.getSelectedKey();
					console.log(vCategory);
					switch (vCategory) {
						case "0":
							oBindingParams.filters.push(new sap.ui.model.Filter("PrimaryStatus", sap.ui.model.FilterOperator.EQ, "M300"));
							oBindingParams.filters.push(new sap.ui.model.Filter("SecondaryStatus", sap.ui.model.FilterOperator.EQ, "S300"));
							oBindingParams.filters.push(new sap.ui.model.Filter("InventoryStatus", sap.ui.model.FilterOperator.EQ, "Stock"));
							break;
						case "1":
							// 	oBindingParams.filters.push(new sap.ui.model.Filter("PrimaryStatus", sap.ui.model.FilterOperator.EQ, "M300"));
							// 	oBindingParams.filters.push(new sap.ui.model.Filter("SecondaryStatus", sap.ui.model.FilterOperator.EQ, "S400"));
							// 	oBindingParams.filters.push(new sap.ui.model.Filter("VehicleUsage", sap.ui.model.FilterOperator.EQ, "2C"));
							oBindingParams.filters.push(new sap.ui.model.Filter("InventoryStatus", sap.ui.model.FilterOperator.EQ, "Stock-Demo"));
							break;
						case "2":
							// 	oBindingParams.filters.push(new sap.ui.model.Filter("PrimaryStatus", sap.ui.model.FilterOperator.EQ, "M300"));
							// 	oBindingParams.filters.push(new sap.ui.model.Filter("SecondaryStatus", sap.ui.model.FilterOperator.EQ, "S400"));
							// 	oBindingParams.filters.push(new sap.ui.model.Filter("VehicleUsage", sap.ui.model.FilterOperator.EQ, "1B"));
							oBindingParams.filters.push(new sap.ui.model.Filter("InventoryStatus", sap.ui.model.FilterOperator.EQ, "Stock-B-Stock"));
							break;
						case "3":
							//oBindingParams.filters.push(new sap.ui.model.Filter("PrimaryStatus", sap.ui.model.FilterOperator.StartsWith, "M0"));
							oBindingParams.filters.push(new sap.ui.model.Filter("InventoryStatus", sap.ui.model.FilterOperator.EQ,
								"Pipeline-Production Pending"));
							break;
						case "4":
							//oBindingParams.filters.push(new sap.ui.model.Filter("PrimaryStatus", sap.ui.model.FilterOperator.StartsWith, "M1"));
							oBindingParams.filters.push(new sap.ui.model.Filter("InventoryStatus", sap.ui.model.FilterOperator.EQ,
								"Pipeline- in Production"));

							break;
						case "5":
							//oBindingParams.filters.push(new sap.ui.model.Filter("PrimaryStatus", sap.ui.model.FilterOperator.StartsWith, "M2"));
							oBindingParams.filters.push(new sap.ui.model.Filter("InventoryStatus", sap.ui.model.FilterOperator.EQ, "Pipeline- in Transit"));

							break;
						default:
							break;
					}
				}
			}
		},

		handleRouteMatched: function(oEvent) {
			var oParams = {};

			if (oEvent.mParameters.data.context) {
				this.sContext = oEvent.mParameters.data.context;
				var oPath;
				if (this.sContext) {
					oPath = {
						path: "/" + this.sContext,
						parameters: oParams
					};
					this.getView().bindObject(oPath);
				}
			}

		},
		_onFioriListReportTableItemPress: function(oEvent) {

			var oBindingContext = oEvent.getParameter("listItem").getBindingContext();

			return new Promise(function(fnResolve) {
				this.doNavigate("VehicleDetails", oBindingContext, fnResolve, "");
			}.bind(this)).catch(function(err) {
				if (err !== undefined) {
					MessageBox.error(err.message);
				}
			});

		},

		_onFioriListReportTableUpdateFinished: function(oEvent) {
			var oTable = oEvent.getSource();
			var oHeaderbar = oTable.getAggregation("headerToolbar");
			if (oHeaderbar && oHeaderbar.getAggregation("content")[1]) {
				var oTitle = oHeaderbar.getAggregation("content")[1];
				if (oTable.getBinding("items") && oTable.getBinding("items").isLengthFinal()) {
					oTitle.setText("(" + oTable.getBinding("items").getLength() + ")");
				} else {
					oTitle.setText("(1)");
				}
			}

		},

		onCollapseExpandPress: function() {
			var oSideNavigation = this.byId("sideNavigation");
			var bExpanded = oSideNavigation.getExpanded();
			oSideNavigation.setExpanded(!bExpanded);
		},
		onInit: function() {

			//	var oVehicle_catalog = this.getOwnerComponent().getModel("vehicleDataModel");
			//console.log(oVehicle_catalog);
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("VehicleList").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));

			this.oVehicleType = {
				"stat": "Stock",
				"orderType": "National"
			};

			this.oModel = new JSONModel();

			this.oModel.setProperty("/oCustomStock", this.oVehicleType);
			this.getView().setModel(this.oModel, "LocalModel");

			// var oLocalModel = this.getOwnerComponent().getModel("LocalDataModel");
			// oLocalModel.setProperty("/VehicleTypeData", oVehicleType);

			//this.oVehicleModel = new sap.ui.model.odata.ODataModel("/DG2_200/sap/opu/odata/sap/Z_VEHICLE_MASTER_SRV");
			this.oVehicleModel = this.getOwnerComponent().getModel();

			var oCustomerModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/CB_CUSTOMER_SRV/");
			this.getView().setModel(oCustomerModel, "oGetCustomerModel");

		},
		onQualSearch: function(oEvent) {

			this.oSelectedItem = oEvent.getParameters().selectedItem.mProperties.text;

			this.oVehicleType.stat = this.oSelectedItem;

			var oSmartTable = this.byId("LineItemsSmartTable");
			oSmartTable.rebindTable();
			this.getOwnerComponent().getModel().refresh();
			//oSmartTable.showOverlay();
		},

		onOrderTypeSearch: function(oEvent) {

			this.oSelectedItem = oEvent.getParameters().selectedItem.mProperties.text;

			this.oVehicleType.orderType = this.oSelectedItem;

			var oSmartTable = this.byId("LineItemsSmartTable");
			oSmartTable.rebindTable();
			this.getOwnerComponent().getModel().refresh();
			//oSmartTable.showOverlay();
		},

		OnSelectionChange: function(oEvent) {
			var oSpath = oEvent.getParameter("listItem").getBindingContext().sPath;
			var obj = oEvent.getSource().getModel().getProperty(oEvent.getParameter("listItem").getBindingContext().sPath);
			console.log(obj, oSpath);
			var oVguid = oSpath.split("'")[1];
			console.log(oVguid);

			var oGetCustomerMo = this.getView().getModel("oGetCustomerModel");
			console.log(oGetCustomerMo);
			oGetCustomerMo.read("Customers('" + obj.Customer + "')", {
				success: $.proxy(function(data) {
					//console.log(data);
					this.getOwnerComponent().getModel("LocalDataModel").setProperty("/CustomerData", data);
				}, this),

				error: function() {
					console.log("Error");
				}
			});

			this.getOwnerComponent().getRouter().navTo("VehicleDetails", {
				oid: obj.VehicleModel,
				ogid: oVguid

			});

		},

		fnFormatter: function(text, key) {
			var sText = "";

			if (text && key) {
				sText += (text + " (" + key + ")");
			} else if (text) {
				sText += text;
			} else if (key) {
				sText += key;
			}

			return sText;
		},
		fnFormatCustomer: function(val) {
			var sTrimval;
			val.toString();
			if (val) {

				sTrimval = val.substr(5);
				//console.log(sTrimval);

			}
			return sTrimval;

		},
		handleSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Customer", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		onSelection: function(oEvent) {
			//debugger;
			this.objectRow = [];
			//console.log(this.oVehicleModel);
			var oArr = oEvent.getSource().getSelectedContextPaths();
			if (oArr.length > 0) {
				this.getView().byId("idDealerBtn").setProperty("enabled", true);
			} else {
				this.getView().byId("idDealerBtn").setProperty("enabled", false);
			}
			oArr.forEach($.proxy(function(item) {
				var oObject = oEvent.getSource().getModel().getProperty(item);
				// if (oObject.SecondaryStatus === "S300" || oObject.SecondaryStatus === "S010") {
				this.getView().byId("idDealerBtn").setProperty("enabled", true);
				this.objectRow.push(oObject.VehicleIdentificationNumber);

			}), this);

			//console.log(this.objectRow);

		},
		onPressAssignDealers: function(oEvent) {

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("zdi.view.fragments.AssignToDealerDialog", this);
				this.getView().addDependent(this._oDialog);

				this.oCustomerModel = new JSONModel();
				this.oCustomerModel.loadData(jQuery.sap.getModulePath("zdi.utils", "/customers.json"));
				this.getView().setModel(this.oCustomerModel, "CustomersModel");

			}
			// Remember selections if required
			var bRemember = !!oEvent.getSource().data("remember");
			this._oDialog.setRememberSelections(bRemember);

			// clear the old search filter
			this._oDialog.getBinding("items").filter([]);
			this._oDialog.open();
		},
		handleClose: function(oEvent) {

			var aContexts = oEvent.getParameter("selectedContexts");

			if (aContexts && aContexts.length) {
				this.oCustomerNum = aContexts.map(function(oContext) {
					return oContext.getObject().Customer;
				}).join();

				var requestBody = {};
				requestBody.Endcustomer = this.oCustomerNum;

				requestBody.VehicleSet = [];
				console.log(this.objectRow.length);
				for (var i = 0; i < this.objectRow.length; i++) {
					requestBody.VehicleSet.push({
						Vehicleidentnumb: this.objectRow[i]
					});
				}

				var oVehicleModel = this.getOwnerComponent().getModel();

				oVehicleModel.create("/CustomerSet", requestBody, {
					success: function() {
						console.log("success");

						MessageToast.show("Vehicle have been assigned to Dealer: " + aContexts.map(function(oContext) {

							return oContext.getObject().Customer.substr(5);
						}).join(", "));
					},
					error: function() {
						console.log("error");
					}
				});
				console.log(requestBody);
				oVehicleModel.refresh();

			}

			oEvent.getSource().getBinding("items").filter([]);
		}

	});

});