function initModel() {
	var sUrl = "/DG2_200/sap/opu/odata/sap/API_BUSINESS_PARTNER/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}